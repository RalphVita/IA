
## Executar
```shell
python3 trab2.py
```