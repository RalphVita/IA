class IState:
    def Value(self):
        pass
    def NextState(self):# -> IState:
        pass
    def Equal(self, other):
        pass
    def Compare(self, other):
        pass